const utilities = [
  {
    id: 1,
    title: "Figma",
    href: "https://www.figma.com",
  },
  {
    id: 2,
    title: "Firebase",
    href: "https://firebase.google.com",
  },
  {
    id: 3,
    title: "Bootstrap",
    href: "https://getbootstrap.com",
  },
  {
    id: 4,
    title: "GitHub",
    href: "https://github.com",
  },
];

export default utilities;
