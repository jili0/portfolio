const pageLinks = [
  {
    id: 1, 
    href: '#hero',
    text: 'Start'
  },
  {
    id: 2, 
    href: '#about',
    text: 'About'
  },
  {
    id: 3, 
    href: '#projects',
    text: 'Projects'
  },
  {
    id: 4, 
    href: '#contact',
    text: 'Contact'
  },
  
]

export default pageLinks